#pragma once

#include "ofMain.h"

class ofApp : public ofBaseApp {

public:
	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y);
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);

	/* WaterFall-related member variables Regions */

	// flag variables
	int draw_flag;
	int load_flag;
	
	int range_flag;

	// Line segment and dot related variables
	int num_of_line, num_of_dot;
	float dot_diameter;

	/* WaterFall-related member functions */

	void processOpenFileSelection(ofFileDialogResult openFileResult);
	void initializeWaterLines(); // 2nd week portion.

};

class Point {
private:
	int xpos, ypos;
public:
	Point();
	Point(int _x, int _y);
	void setX(int _x);
	void setY(int _y);
	int getX() const;
	int getY() const;
};

class LineSegment {
private:
	Point leftP, rightP;
public:
	LineSegment(int xl, int yl, int xr, int yr);
	int getLX() const;
	int getLY() const;
	int getRX() const;
	int getRY() const;
};

class Waterfall {
private:
	int wh;
	int sh;
	int pos;	//	������ ���� index
public:
	Point** waterhole;
	LineSegment** shelf;
	Waterfall();
	~Waterfall();
	void setWH(int _wh);
	void setSH(int _sh);
	void setPos(int _pos);
	int getWH() const;
	int getSH() const;
	int getPos() const;
};
