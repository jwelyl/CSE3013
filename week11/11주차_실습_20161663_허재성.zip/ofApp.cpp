#include "ofApp.h"

Waterfall* wf = NULL;

//--------------------------------------------------------------
void ofApp::setup() {
    ofSetFrameRate(15); // Limit the speed of our program to 15 frames per second

    // We still want to draw on a black background, so we need to draw
    // the background before we do anything with the brush
    ofBackground(255, 255, 255);
    ofSetLineWidth(4);

    //   ofSetColor(0);

    draw_flag = 0;
    load_flag = 0;

    range_flag = 0; //  ���� �ʰ� �÷���, 0�� �� �ʰ� x
    water_flag = 0; //  �� �ٱ� �׷����� 1, �׷��� ������ 0
    dot_diameter = 10.0f;
}

//--------------------------------------------------------------
void ofApp::update() {

}

//--------------------------------------------------------------
void ofApp::draw() {
 //   cout << "draw �Լ� ����!" << endl;
    ofSetColor(127, 23, 31);  // Set the drawing color to brown

    // Draw shapes for ceiling and floor
    ofDrawRectangle(0, 0, 1024, 40); // Top left corner at (50, 50), 100 wide x 100 high
    ofDrawRectangle(0, 728, 1024, 40); // Top left corner at (50, 50), 100 wide x 100 high
    ofSetLineWidth(5);


    ofSetLineWidth(5);
    if (draw_flag) {


        /* COMSIL1-TODO 3 : Draw the line segment and dot in which water starts to flow in the screen.
         Note that after drawing line segment and dot, you have to make selected water start dot colored in red.
         */

        for (int idx = 0; idx < wf->getSH(); idx++) {
            ofDrawLine(wf->shelf[idx]->getLX(), wf->shelf[idx]->getLY(), wf->shelf[idx]->getRX(), wf->shelf[idx]->getRY());
        }

        for (int idx = 0; idx < wf->getWH(); idx++) {
            if (idx == wf->getPos()) ofSetColor(255, 0, 0);
            else ofSetColor(0, 0, 0);
            ofDrawCircle(wf->waterhole[idx]->getX(), wf->waterhole[idx]->getY(), dot_diameter);
        }

        // 2nd week portion.
        ofSetLineWidth(2);
    }

    if (draw_flag && water_flag) {
        ofSetColor(128, 173, 255);
        ofSetLineWidth(4);
        WaterSegment* cur;
        for (cur = wf->head[wf->getPos()]; cur; cur = cur->link) {
        //    cout << "�� (" << cur->getLX() << ", " << cur->getLY() << "), (" << cur->getRX() << ", " << cur->getRY() << ") �� �մ� ���� �׸�" << endl;
            ofDrawLine(cur->getLX(), cur->getLY(), cur->getRX(), cur->getRY());
        }
    }
 //   cout << "draw �Լ� ��!" << endl;
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
    if (key == 'v') {
        // HACK: only needed on windows, when using ofSetAutoBackground(false)
        glReadBuffer(GL_FRONT);
        ofSaveScreen("savedScreenshot_" + ofGetTimestampString() + ".png");
    }
    if (key == 'q') {
        // Reset flags
        draw_flag = 0;

        // Free the dynamically allocated memory exits.
        if (wf) {
            delete wf;
            wf = NULL;
        }
        cout << "Dynamically allocated memory has been freed." << endl;

        _Exit(0);
    }
    if (key == 'd') {
        if (!load_flag || water_flag) {
            return;
        }
        /* COMSIL1-TODO 2: This is draw control part.
        You should draw only after when the key 'd' has been pressed.
        */
        draw_flag = 1;
        wf->setPos(0);
        draw();
    }
    if (key == 's') {
        // 2nd week portion.
        if (!load_flag || !draw_flag || water_flag) {
            return;
        }
        water_flag = 1;
        draw();
    }
    if (key == 'e') {
        // 2nd week portion.
        if (!load_flag || !draw_flag) {
            return;
        }
        water_flag = 0;
        draw();
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {
    if (key == 'l') {
        // Open the Open File Dialog

        //  ���� ���� ���� draw_flag, load_flag, water_flag 0���� ����
        draw_flag = 0;
        load_flag = 0;
        water_flag = 0;
        ofFileDialogResult openFileResult = ofSystemLoadDialog("Select a only txt for Waterfall");

        // Check whether the user opened a file
        if (openFileResult.bSuccess) {
            ofLogVerbose("User selected a file");

            // We have a file, so let's check it and process it
            processOpenFileSelection(openFileResult);
            if (!range_flag) load_flag = 1;  //  ���� �ʰ� ���� �� load_flag�� 1�� ����
            else range_flag = 0;    //  load_flag�� 0���� �����ϰ� range_flag �ٽ� 0���� ����
        }
    }

    /* COMSIL1-TODO 4: This is selection dot control part.
     You can select dot in which water starts to flow by left, right direction key (<- , ->).
     */

    if (key == OF_KEY_RIGHT) {
        if (draw_flag && !water_flag) {
            int pos = wf->getPos();
            if (pos == wf->getWH() - 1) {
                wf->setPos(0);
            }
            else {
                wf->setPos(++pos);
            }
            draw();

            cout << "Selected Dot Coordinate is (" <<
                wf->waterhole[wf->getPos()]->getX() << ", " <<
                wf->waterhole[wf->getPos()]->getY() << ")" << endl;
        }
    }
    if (key == OF_KEY_LEFT) {
        if (draw_flag && !water_flag) {
            int pos = wf->getPos();
            if (pos == 0) {
                wf->setPos(wf->getWH() - 1);
            }
            else {
                wf->setPos(--pos);
            }
            draw();

            cout << "Selected Dot Coordinate is (" <<
                wf->waterhole[wf->getPos()]->getX() << ", " <<
                wf->waterhole[wf->getPos()]->getY() << ")" << endl;
        }
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}

void ofApp::processOpenFileSelection(ofFileDialogResult openFileResult) {
    //Path to the comma delimited file
    //string fileName = "input.txt";

    string fileName = openFileResult.getName();
    ofFile file(fileName);

    if (!file.exists()) {
        cout << "Target file does not exists." << endl;
        return;
    }
    else cout << "We found the target file." << endl;

    ofBuffer buffer(file);

    /* This variable is for indicating which type of input is being received.
     IF input_type == 0, then work of getting line input is in progress.
     IF input_type == 1, then work of getting dot input is in progress.
     */
    int input_type = 0;
    int i = 0;
    int sh = 0, wh = 0;

    /* COMSIL1-TODO 1 : Below code is for getting the number of line and dot, getting coordinates.
     You must maintain those information. But, currently below code is not complete.
     Also, note that all of coordinate should not be out of screen size.
     However, all of coordinate do not always turn out to be the case.
     So, You have to develop some error handling code that can detect whether coordinate is out of screen size.
    */
    if (wf) {
        //    cout << "������ �Ҵ�� wf ����" << endl;
        delete wf;
        wf = NULL;
        //   cout << "������ �Ҵ�� wf ���� �Ϸ�" << endl;
    }
    wf = new Waterfall();

    // Read file line by line
    for (ofBuffer::Line it = buffer.getLines().begin(), end = buffer.getLines().end(); it != end; ++it) {
        string line = *it;

        // Split line into strings
        vector<string> words = ofSplitString(line, " ");

        if (words.size() == 1) {
            if (input_type == 0) { // Input for the number of lines.
                num_of_line = atoi(words[0].c_str());
                cout << "The number of line is: " << num_of_line << endl;
                wf->setSH(num_of_line);
                wf->shelf = new LineSegment * [wf->getSH()];
                for (int j = 0; j < wf->getSH(); j++) {
                    wf->shelf[j] = NULL;
                }
            }
            else { // Input for the number of dots.
                num_of_dot = atoi(words[0].c_str());
                cout << "The number of dot is: " << num_of_dot << endl;
                wf->setWH(num_of_dot);
                wf->waterhole = new Point * [wf->getWH()];
                wf->head = new WaterSegment * [wf->getWH()];   //  �� �ٱ⸦ ǥ���� ���� ����Ʈ�� head �迭 �Ҵ�
                wf->tail = new WaterSegment * [wf->getWH()];    //  �� �ٱ⸦ ǥ���� ���� ����Ʈ�� tail �迭 �Ҵ�

                for (int j = 0; j < wf->getWH(); j++) {
                    wf->waterhole[j] = NULL;
                    wf->head[j] = NULL;
                    wf->tail[j] = NULL;
                }
            }
        }
        else if (words.size() >= 2) {
            int x1, y1, x2, y2;

            if (input_type == 0) { // Input for actual information of lines
                x1 = atoi(words[0].c_str());
                y1 = atoi(words[1].c_str());
                x2 = atoi(words[2].c_str());
                y2 = atoi(words[3].c_str());

                if (((x1 < 0 || x1 > 1024) || (y1 < 40 || y1 > 728))
                    || ((x2 < 0 || x2 > 1024) || (y2 < 40 || y2 > 728))) {
                    cout << "������ ��� �Է�" << endl;
                    range_flag = 1; //  ���� �ʰ� �÷��� ����
                    return;
                }     
                else if (x1 == x2) {
                    cout << "���� ���� �Է�" << endl;
                    range_flag = 1;
                    return;
                }
                else if (y1 == y2) {
                    cout << "���� ���� �Է�" << endl;
                    range_flag = 1;
                    return;
                }
                
                wf->shelf[sh++] = new LineSegment(x1, y1, x2, y2);

                i++;
                if (i == num_of_line) input_type = 1;
            }
            else { // Input for actual information of dots.
                x1 = atoi(words[0].c_str());
                y1 = atoi(words[1].c_str());

                if ((x1 < 0 || x1 > 1024) || (y1 < 40 || y1 > 728)) {
                    cout << "������ ��� �Է�" << endl;
                    range_flag = 1;
                    return;
                }

                wf->waterhole[wh] = new Point(x1, y1);
                wf->head[wh] = new WaterSegment(*(wf->waterhole[wh]));
                wf->tail[wh] = wf->head[wh];    //  ó������ tail�� head�� ���� ��带 ����Ŵ.
                wh++;
            }
        } // End of else if.
    } // End of for-loop (Read file line by line).

    initializeWaterLines();
 //   wf->createWaterfallList();
}

void ofApp::initializeWaterLines() {
    wf->createWaterfallList();
}


Point::Point() {
    xpos = 0;
    ypos = 0;
}

Point::Point(float _x, float _y) : xpos(_x), ypos(_y) {
}

void Point::setX(float _x) {
    xpos = _x;
}

void Point::setY(float _y) {
    ypos = _y;
}

float Point::getX() const {
    return xpos;
}

float Point::getY() const {
    return ypos;
}

LineSegment::LineSegment(float xl, float yl, float xr, float yr) {
    leftP.setX(xl);
    leftP.setY(yl);
    rightP.setX(xr);
    rightP.setY(yr);
    //  LineSegment ������ ����
    slope = (yr - yl) / (xr - xl);
}

float LineSegment::getLX() const {
    return leftP.getX();
}

float LineSegment::getLY() const {
    return leftP.getY();
}

float LineSegment::getRX() const {
    return rightP.getX();
}
float LineSegment::getRY() const {
    return rightP.getY();
}

float LineSegment::getSlope() const {
    return slope;
}

WaterSegment::WaterSegment(Point& start) 
    : LineSegment(start.getX(), start.getY(), start.getX(), 728), link(NULL) 
{}

void WaterSegment::setLP(Point& _lp) {
    leftP.setX(_lp.getX());
    leftP.setY(_lp.getY());
}

void WaterSegment::setRP(Point& _rp) {
    rightP.setX(_rp.getX());
    rightP.setY(_rp.getY());
}

Waterfall::Waterfall() {
    waterhole = NULL;
    shelf = NULL;
    head = NULL;
    tail = NULL;
    wh = 0;
    sh = 0;
    pos = 0;
}

Waterfall::~Waterfall() {
    for (int i = 0; i < wh; i++) {
        if (waterhole[i]) {
            delete waterhole[i];
            waterhole[i] = NULL;
        }
    }
    for (int i = 0; i < sh; i++) {
        if (shelf[i]) {
            delete shelf[i];
            shelf[i] = NULL;
        }
    }

    if (head) {
        for (int i = 0; i < wh; i++) {
            tail[i] = NULL;
            for (WaterSegment* del = head[i]; del;) {
                if (del->link) head[i] = del->link;
                else head[i] = NULL;
                
                del->link = NULL;
                delete del;
                del = head[i];
            }
        }
        delete[] head;
        delete[] tail;
        head = NULL;
        tail = NULL;
    }
   
    delete[] waterhole;
    delete[] shelf;

    waterhole = NULL;
    shelf = NULL;
}

void Waterfall::setWH(int _wh) {
    wh = _wh;
}

void Waterfall::setSH(int _sh) {
    sh = _sh;
}

void Waterfall::setPos(int _pos) {
    pos = _pos;
}

int Waterfall::getWH() const {
    return wh;
}

int Waterfall::getSH() const {
    return sh;
}

int Waterfall::getPos() const {
    return pos;
}

void Waterfall::createWaterfallList() { //  ���ٱ⸦ ǥ���ϴ� LinkedList ����
//    bool* flag;

    if (!head) {
        cout << "head�� �Ҵ���� ����!" << endl;
        return;
    }

    for (int i = 0; i < wh; i++) {  //  �� �� ���ۿ� ���Ͽ�
        int intersection;       //  ���θ��� ������ ����
        
 //       cout << i + 1 << "��° ������" << endl;
        do {
            float minY = 768;       //  ���� ����� ���θ��� ���ݰ��� ������ y ��ǥ
            float yIntersect;       //  ���θ��� ���� �ִ� �ĺ� ���ݰ��� ������ y ��ǥ
            int shelf_idx = sh;     //  ���� ������ ���θ��� ������ index

           
            intersection = 0;   
            for (int k = 0; k < sh; k++) {  //  ��� ������ Ž����     
                if (tail[i]->getLX() < shelf[k]->getLX()
                    || shelf[k]->getRX() < tail[i]->getLX()) {
                    continue;  //  ������ x ��ǥ ������ �� ���� x ��ǥ�� ���� �ȵ�, ���� �������� �Ѿ
                }
                else {
                    //  ���⸦ �̿��Ͽ� ������ y ��ǥ ����
                    yIntersect = (shelf[k]->getSlope()) * (tail[i]->getLX() - shelf[k]->getRX()) + shelf[k]->getRY();
                    if (yIntersect <= tail[i]->getLY()) {
                        continue;    //  ������ �� ���ۺ��� ���� ����, ���� �������� �ѰŰ�
                    }
                    else {
                        if (minY > yIntersect) {
                            minY = yIntersect;
                            shelf_idx = k;
                        }
                        intersection++;
                    }
                }
            }
            if (intersection != 0) {    //  ���ٱ⸦ ���θ��� ������ ���� ���
                float endX, endY;
                if (shelf[shelf_idx]->getLY() > shelf[shelf_idx]->getRY()) {
                    endX = shelf[shelf_idx]->getLX();
                    endY = shelf[shelf_idx]->getLY();
                }
                else {
                    endX = shelf[shelf_idx]->getRX();
                    endY = shelf[shelf_idx]->getRY();
                }    //  ������ �� ������ y ��ǥ�� ���Ͽ� �� ū y ��ǥ�� ã��

                Point intersect(tail[i]->getLX(), minY);    //  ���� ��ü ����
                Point end(endX, endY);  //  ���� ��ü ����
                tail[i]->setRP(intersect);  //  tail�� ����Ű�� WaterSegment�� ������ �������� ������
                WaterSegment* newSeg1 = new WaterSegment(intersect); //  ������ ���������� �ϴ� ���ο� WaterSegment ��ü ����
                newSeg1->setRP(end); //  ������ ������ �������� ��.

                tail[i]->link = newSeg1; //  ���� WaterSegment ����Ʈ�� ���̶� ����
                tail[i] = newSeg1;       //  newSeg�� �� ���� ����. (����Ʈ�� ���� �Ϸ�)

                WaterSegment* newSeg2 = new WaterSegment(end);  //  �� ���� ���������� �ϴ� ���ο� WaterSegment ��ü ����

                tail[i]->link = newSeg2; //  ���� WaterSegment ����Ʈ�� ���̶� ����
                tail[i] = newSeg2;       //  newSeg2�� �� ���� ����. (����Ʈ�� ���� �Ϸ�)
            }
        } while (intersection != 0);
    } 
}

